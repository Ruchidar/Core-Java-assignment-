
package com;

public class ProductManagement {

 
    public static void main(String[] args) {
        ProductConsole pc = new ProductConsole();
        pc.start();
    }
    
}
