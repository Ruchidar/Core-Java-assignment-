package com.sambuddha.medicine;

public interface MedicineInfo {
	void displayLabel();
}
